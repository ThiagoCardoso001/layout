import { createDrawerNavigator } from "@react-navigation/drawer"
import { NavigationContainer } from "@react-navigation/native"
import Acoes from "../../view/Acoes"
import CompraAcoes from "../../view/CompraAcoes"
import CompraFundos from "../../view/CompraFundos"
import Fundos from "../../view/Fundos"
import Home from "../../view/Home"
import Login from "../../view/Login"


const Drawer = createDrawerNavigator()

export default menuDrawerNavigator = ()=>{

    return(
        <NavigationContainer>
            <Drawer.Navigator initialRouteName="home">
                <Drawer.Screen name="acoes" component={Acoes} 
                options={{headerTitle: ""}}/>
                <Drawer.Screen name="compraAcoes" component={CompraAcoes} 
                options={{headerTitle: ""}}/>
                <Drawer.Screen name="compraFundos" component={CompraFundos} 
                options={{headerTitle: ""}}/>
                <Drawer.Screen name="fundos" component={Fundos} 
                options={{headerTitle: ""}}/>
                <Drawer.Screen name="home" component={Home} 
                options={{headerTitle: ""}}/>
                <Drawer.Screen name="login" component={Login} 
                options={{headerTitle: ""}}/>
            </Drawer.Navigator>
        </NavigationContainer>
    )

}