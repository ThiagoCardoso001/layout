import { StyleSheet, Text, View } from "react-native"

export default Acoes = ()=>{

    return(
        <View style={estilo.container}>

            <Text>AÇÕES</Text>

        </View>        
    )

}

const estilo = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
      },
})