import { StyleSheet, Text, View } from "react-native"

export default CompraFundos = ()=>{

    return(
        <View style={estilo.container}>

            <Text>HOME</Text>
            <Text>Bem vindo ao InvestMais, o seu futuro começa aqui!</Text>

        </View>        
    )

}

const estilo = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
      },
})