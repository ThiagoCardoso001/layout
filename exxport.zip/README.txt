
Thank you for downloading this template. Please check our license and restrictions.

LICENSE

This template is free for non-commercial use only. You can use it for free if you are building a non profit personal website, a non profit organization website 
or a website for educational purposes (schools, universities...). In such cases, please keep the footer credit link visible and unchanged.
It is prohibited to share, resell, redistribute the free template. The use of our template implies that you have read and accepted our Terms of Service.

COMMERCIAL USE

If you use this template to build a website for a commercial activity or a website generating any kind of revenue for you or your client, you must purchase this template.
By commercial website, we mean a website generating any kind of revenue including advertising revenues such as Google Ads. This is a limited license valid only for 
one website. You are free to keep or remove the credit backlink of a purchased template.


Before applying our template on your website, make sure that you do a necessary backup.

For more information about our licenses, please check our website. If you have any question regarding template licensing, please contact us at mail@dotemplate.com.

Thank you again !

doTemplate team.
